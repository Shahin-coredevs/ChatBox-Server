import React from 'react';
import Routers from './Routers/Routers';

function App() {
  return (
    <Routers />
  );
}

export default App;
