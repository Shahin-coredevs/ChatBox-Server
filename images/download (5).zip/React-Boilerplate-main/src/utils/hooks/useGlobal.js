export default function useGlobal() {
    return {

    };
}