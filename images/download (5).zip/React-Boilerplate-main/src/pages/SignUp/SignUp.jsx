import React from 'react';

const SignUp = () => (
  <div>
    Signup
  </div>
);

export default SignUp;
