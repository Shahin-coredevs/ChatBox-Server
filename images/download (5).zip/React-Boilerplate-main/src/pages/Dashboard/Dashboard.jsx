import React from 'react';

const Dashboard = () => {
    return (
        <div className='p-5 bg-orange-500 h-full'>
            <p>Dashboard Outlet</p>
           
        </div>
    );
};

export default Dashboard;