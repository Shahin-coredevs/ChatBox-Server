import React from 'react';
// import styles from './login.module.css';

const Login = () => (
  <div className='container mx-auto text-center'>
    Login
  </div>
);

export default Login;
