import React from 'react'

const Shop = () => {
  return (
    <div className='container mx-auto text-center'>
      Shop
    </div>
  )
}

export default Shop;
